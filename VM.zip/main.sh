cmake --preset linux
cmake --build build --target main
